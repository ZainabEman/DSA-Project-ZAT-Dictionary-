#include "LOAD_.h"
using namespace System;
using namespace System::Windows::Forms;


int main()
{
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	DSProject::LOAD_ form;
	Application::Run(% form);





}